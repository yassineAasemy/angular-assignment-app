binome: AASEMY YASSINE
        AYOUB ASSRI

ameliorations apportées: authentificatoin avec Jwt
/*il reste encore qq petits bugg que j'essai de corriger :(
la chaine de cnx avec mongodb cloud n'a pas marché pour moi, j'ai trouvé
un tuto qui montre comment faire on local
https://www.youtube.com/watch?v=brb4SO-dO_k

étapes à suivre pour demarrer le projet:

1- installer docker sur votre machine

2- executer les commandes suivantes:
2-1: telecharger ou cloner le projet: git clone  https://github.com/yassineAasemy/angular-assignment-app.git
2-2: doker-compose up
2-3: docker exec backend /bin/sh start.sh
l'api back-end sera pret sur le port http://localhost:8000

3- pour la partie front:
3-1: telecharger ou cloner le projet avec: git clone  https://github.com/yassineAasemy/auth-api-main.git
3-2: npm install
3-3: ng serve


references et ressource
youtube/stackoverflow
https://www.pluralsight.com/paths/angular
https://github.com/scalablescripts/auth
https://github.com/DeborahK/APM-Final